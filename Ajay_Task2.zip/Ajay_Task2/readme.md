Loundry Wallah

This is a Practice task -2 of HTML 

I have used all the things that I have learned. Please tell me if there is any issue 

AJAY KUMAR
at3855073@gamil.com
